package br.com.escola;

import java.util.Scanner;
import br.com.escola.model.aluno;
import br.com.escola.model.turma;
import br.com.escola.service.escolaservice;

@SuppressWarnings("java:S106")
public class main {
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		escolaservice service = new escolaservice();
		int opcao;
	do {
		System.out.println("/n===== SISTEMA ESCOLAR =====");
		System.out.println("1 - Cadastrar turma");
		System.out.println("2 - Listar Turmas");
		System.out.println("3 - Cadastrar aluno em turma");
		System.out.println("4 - Listar alunos de uma turma");
		System.out.println("5 - Sair");
		System.out.println("Escolha: ");
		
	opcao = scanner.nextInt();
	scanner.nextLine();
	}
	
	switch (opcao) {
	
	case 1:
		System.out.println("Nome Da Turma: ");
		String nomeTurma = scanner.nextLine();
		service.adicionarTurma(newTurma(nomeTurma));
		System.out.println("Turma Cadastrada com sucesso!");
		break;
		
		case 2:
			listarTurmas(service);
			break;
			
		case 3:
			cadastrarAluno(scanner, service);
			break;
		
		case 4:
			listarAluno(scanner, service);
			break;
			
		case 5:
			System.out.println("Encerrando o sistema. Até Logo.");
			break;
			
		default:
			System.out.println("Opção Invalida! Digite um numero de 1 a 5");
	}
	
	private static void listarTumas(EscolaService service) {
		
	if (service.estaVazia){
			System.out.println("Nenhuma turma cadastraa ainda.");
			return;
}
		
		System.out.println("\n--- Turmas Cadastradas ---");
			
	for (int i=0; i < service.listarTurmas.size(); i++) {
		System.out.println(i + " - " + service.listarTurmas().get(i));
	}
	
	private static void cadastrarAluno(Scanner scanner, EscolaService service) {
		if (service.estaVazia()) {
			System.out.println("Cadastre uma turma primeiro!");
			return;
}
		listarTurmas(service);
		
		System.out.println("Escolha o indice da turma: ");
		int indice = scanner.nextInt();
		scanner.nextLine();
		
		turma turma = service.buscarTurma(indice);
		
		if (turma == null) {
			System.out.println("indice invalido. Nenhuma turma encontrada");
			return;
		}
		
		System.out.println("Nome do aluno: ");
		String nome = scanner.nextLine();
		
		System.out.println("Nota 1: ");
		String nota1 = scanner.nextDouble();
		
		System.out.println("Nota 2: ");
		String nota2 = scanner.nextDouble();
		scanner.nextLine();
		
		turma.adicionarAluno(new Aluno(nome, nota1, nota2));
		System.out.println("Aluno cadastrado com sucesso!");
		
	}
	
	private static void listarAluno(Scanner scanner, Escolaservice service) {
		if (service.estaVazia()) {
			System.out.println("Nenhuma turma cadastrada ainda.");
			return;
}
		listarTurmas(service);
		
		System.out.println("Escolha o indice da turma: ");
		int indice = scanner.nextInt();
		scanner.nextLine();
		
		turma turma = service.buscarTurma(indice);
		
		if (turma == null) {
			System.out.println("indice invalido. Nenhuma turma encontrada");
			return;
		}
		
		if (turma.getAlunos().isEmpty()) {
			System.out.println("Nenhum aluno cadastrado nesta turma.");
			return;
		}
		
		System.out.println("\n--- Aluno da turma:" + turma.getNome() + "---");
		
		for (Aluno aluno : turma.getAlunos()){
			System.out.println(aluno);
		}
		
			
	}
 }


   




}
